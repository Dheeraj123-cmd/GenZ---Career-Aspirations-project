create database GenZ_Career_Aspirations;
use GenZ_Career_Aspirations;

select * from master_data;


--Insight 1--
(--Count of respondents influenced by different factors:--)

SELECT [Which of the below factors influence the most about your career ], COUNT(*) AS RespondentCount
FROM master_data
GROUP BY [Which of the below factors influence the most about your career ]
order by RespondentCount


--Insight 2--
(--Percentage of respondents willing to pursue higher education outside of India:--)


select 
[Would you definitely pursue a Higher Education / Post Graduation] AS PursueHigherEducation,
COUNT(*) AS RespondentCount,
(COUNT(*) * 100.0) / (SELECT COUNT(*) FROM master_data) AS Percentage
FROM master_data
GROUP BY [Would you definitely pursue a Higher Education / Post Graduation]
order by RespondentCount;


--Insight 3--
(--Likelihood of working for one employer for 3 years or more:--)

select 
[How likely is that you will work for one employer for 3 years or] AS WorkFor3Years,
COUNT(*) AS RespondentCount,
(COUNT(*) * 100.0) / (SELECT COUNT(*) FROM master_data) AS Percentage
FROM master_data
GROUP BY [How likely is that you will work for one employer for 3 years or]
order by RespondentCount


--Insight 4--
(--Likelihood of working for a company with a misaligned mission:--)

select
[Would you work for a company whose mission is not clearly define] AS CompanyMission,
COUNT(*) AS RespondentCount,
(COUNT(*) * 100.0) / (SELECT COUNT(*) FROM master_data) AS Percentage
FROM master_data
GROUP BY [Would you work for a company whose mission is not clearly define]
order by RespondentCount


--Insight 5--
(--Preferred Working Environment:--)

select 
[What is the most preferred working environment for you#] AS PreferredWorkingEnvironment,
COUNT(*) AS RespondentCount,
(COUNT(*) * 100.0) / (SELECT COUNT(*) FROM master_data) AS Percentage
FROM master_data
GROUP BY [What is the most preferred working environment for you#]
order by RespondentCount

